//
//  main.m
//  Quick Boot Disk Info
//
//  Created by John Welch on 11/14/17.
//  Copyright © 2017 John Welch. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <AppleScriptObjC/AppleScriptObjC.h>

int main(int argc, const char * argv[]) {
     [[NSBundle mainBundle] loadAppleScriptObjectiveCScripts];
     return NSApplicationMain(argc, argv);
}
